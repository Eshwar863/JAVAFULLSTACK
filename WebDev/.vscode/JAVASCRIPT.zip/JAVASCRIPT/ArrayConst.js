
const cars = ["BMW", "Volvo", "Ford"];


// Accessing elements in an array
function accessArrayElements() {
    console.log(cars);
    console.log(cars[0]);
    console.log(cars[2]);
}

cars[0] = "Toyota"; // Modifying an element in the array

function modifyArrayElement() {
    console.log("Modified array:", cars);
}

// Adding an element to the end of the array
function addElementToEnd() {
    let newElement = prompt("Enter the element to be added to the end of the array:");
    cars.push(newElement);
    console.log("Array after adding element to the end:", cars);
}

// Adding an element to the beginning of the array
function addElementToBeginning() {
    let newElement = prompt("Enter the element to be added to the beginning of the array:");
    cars.unshift(newElement);
    console.log("Array after adding element to the beginning:", cars);
}

addElementToBeginning();
// modifyArrayElement();
// accessArrayElements();
// addElementToEnd();
// addElementToBeginning();
